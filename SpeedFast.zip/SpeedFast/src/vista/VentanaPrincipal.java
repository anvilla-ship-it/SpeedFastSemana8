package vista;

import dao.EntregaDAO;
import dao.PedidoDAO;
import dao.RepartidorDAO;
import modelo.Entrega;
import modelo.Pedido;
import modelo.Repartidor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class VentanaPrincipal extends JFrame {

    private final RepartidorDAO repartidorDAO = new RepartidorDAO();
    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final EntregaDAO entregaDAO = new EntregaDAO();

    private JTextField txtRepId;
    private JTextField txtRepNombre;
    private JTable tablaRepartidores;
    private DefaultTableModel modeloRepartidores;

    private JTextField txtPedId;
    private JTextField txtDireccion;
    private JComboBox<String> comboTipo;
    private JComboBox<String> comboEstado;
    private JTable tablaPedidos;
    private DefaultTableModel modeloPedidos;

    private JTextField txtEntId;
    private JComboBox<Pedido> comboPedido;
    private JComboBox<Repartidor> comboRepartidor;
    private JTextField txtFecha;
    private JTextField txtHora;
    private JTable tablaEntregas;
    private DefaultTableModel modeloEntregas;

    public VentanaPrincipal() {

        setTitle("SpeedFast - Gestión");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane pestañas = new JTabbedPane();

        pestañas.addTab("Repartidores", panelRepartidores());
        pestañas.addTab("Pedidos", panelPedidos());
        pestañas.addTab("Entregas", panelEntregas());

        add(pestañas);

        cargarRepartidores();
        cargarPedidos();
        cargarEntregas();
        cargarCombosEntregas();
    }


    private JPanel panelRepartidores() {

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JPanel formulario = new JPanel(new GridLayout(2, 4, 5, 5));

        txtRepId = new JTextField();
        txtRepId.setEditable(false);

        txtRepNombre = new JTextField();

        JButton btnGuardar = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        formulario.add(new JLabel("ID:"));
        formulario.add(txtRepId);
        formulario.add(new JLabel("Nombre:"));
        formulario.add(txtRepNombre);

        formulario.add(btnGuardar);
        formulario.add(btnActualizar);
        formulario.add(btnEliminar);
        formulario.add(btnLimpiar);

        panel.add(formulario, BorderLayout.NORTH);

        modeloRepartidores = new DefaultTableModel(
                new String[]{"ID", "Nombre"}, 0
        );

        tablaRepartidores = new JTable(modeloRepartidores);

        panel.add(new JScrollPane(tablaRepartidores), BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardarRepartidor());
        btnActualizar.addActionListener(e -> actualizarRepartidor());
        btnEliminar.addActionListener(e -> eliminarRepartidor());
        btnLimpiar.addActionListener(e -> limpiarRepartidor());

        tablaRepartidores.getSelectionModel().addListSelectionListener(e -> {

            int fila = tablaRepartidores.getSelectedRow();

            if (fila >= 0) {

                txtRepId.setText(
                        modeloRepartidores.getValueAt(fila, 0).toString()
                );

                txtRepNombre.setText(
                        modeloRepartidores.getValueAt(fila, 1).toString()
                );
            }
        });

        return panel;
    }

    private void guardarRepartidor() {

        String nombre = txtRepNombre.getText().trim();

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese el nombre del repartidor.");
            return;
        }

        try {

            repartidorDAO.create(new Repartidor(nombre));

            JOptionPane.showMessageDialog(this,
                    "Repartidor registrado correctamente.");

            limpiarRepartidor();
            cargarRepartidores();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void actualizarRepartidor() {

        if (txtRepId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un repartidor.");
            return;
        }

        try {

            Repartidor r = new Repartidor(
                    Integer.parseInt(txtRepId.getText()),
                    txtRepNombre.getText().trim()
            );

            repartidorDAO.update(r);

            JOptionPane.showMessageDialog(this,
                    "Repartidor actualizado.");

            limpiarRepartidor();
            cargarRepartidores();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void eliminarRepartidor() {

        if (txtRepId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un repartidor.");
            return;
        }

        try {

            repartidorDAO.delete(
                    Integer.parseInt(txtRepId.getText())
            );

            JOptionPane.showMessageDialog(this,
                    "Repartidor eliminado.");

            limpiarRepartidor();
            cargarRepartidores();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void limpiarRepartidor() {

        txtRepId.setText("");
        txtRepNombre.setText("");
        tablaRepartidores.clearSelection();
    }

    private void cargarRepartidores() {

        modeloRepartidores.setRowCount(0);

        try {

            List<Repartidor> lista = repartidorDAO.readAll();

            for (Repartidor r : lista) {

                modeloRepartidores.addRow(new Object[]{
                        r.getId(),
                        r.getNombre()
                });
            }

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private JPanel panelPedidos() {

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JPanel formulario = new JPanel(new GridLayout(3, 4, 5, 5));

        txtPedId = new JTextField();
        txtPedId.setEditable(false);

        txtDireccion = new JTextField();

        comboTipo = new JComboBox<>(
                new String[]{"COMIDA", "ENCOMIENDA", "EXPRESS"}
        );

        comboEstado = new JComboBox<>(
                new String[]{"PENDIENTE", "EN_REPARTO", "ENTREGADO"}
        );

        JButton btnGuardar = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        formulario.add(new JLabel("ID:"));
        formulario.add(txtPedId);

        formulario.add(new JLabel("Dirección:"));
        formulario.add(txtDireccion);

        formulario.add(new JLabel("Tipo:"));
        formulario.add(comboTipo);

        formulario.add(new JLabel("Estado:"));
        formulario.add(comboEstado);

        formulario.add(btnGuardar);
        formulario.add(btnActualizar);
        formulario.add(btnEliminar);
        formulario.add(btnLimpiar);

        panel.add(formulario, BorderLayout.NORTH);

        modeloPedidos = new DefaultTableModel(
                new String[]{"ID", "Dirección", "Tipo", "Estado"}, 0
        );

        tablaPedidos = new JTable(modeloPedidos);

        panel.add(new JScrollPane(tablaPedidos),
                BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardarPedido());
        btnActualizar.addActionListener(e -> actualizarPedido());
        btnEliminar.addActionListener(e -> eliminarPedido());
        btnLimpiar.addActionListener(e -> limpiarPedido());

        tablaPedidos.getSelectionModel().addListSelectionListener(e -> {

            int fila = tablaPedidos.getSelectedRow();

            if (fila >= 0) {

                txtPedId.setText(
                        modeloPedidos.getValueAt(fila, 0).toString()
                );

                txtDireccion.setText(
                        modeloPedidos.getValueAt(fila, 1).toString()
                );

                comboTipo.setSelectedItem(
                        modeloPedidos.getValueAt(fila, 2).toString()
                );

                comboEstado.setSelectedItem(
                        modeloPedidos.getValueAt(fila, 3).toString()
                );
            }
        });

        return panel;
    }

    private void guardarPedido() {

        String direccion = txtDireccion.getText().trim();

        if (direccion.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese una dirección.");
            return;
        }

        try {

            Pedido p = new Pedido(
                    direccion,
                    comboTipo.getSelectedItem().toString(),
                    comboEstado.getSelectedItem().toString()
            );

            pedidoDAO.create(p);

            JOptionPane.showMessageDialog(this,
                    "Pedido registrado correctamente.");

            limpiarPedido();
            cargarPedidos();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void actualizarPedido() {

        if (txtPedId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un pedido.");
            return;
        }

        try {

            Pedido p = new Pedido(
                    Integer.parseInt(txtPedId.getText()),
                    txtDireccion.getText().trim(),
                    comboTipo.getSelectedItem().toString(),
                    comboEstado.getSelectedItem().toString()
            );

            pedidoDAO.update(p);

            JOptionPane.showMessageDialog(this,
                    "Pedido actualizado.");

            limpiarPedido();
            cargarPedidos();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void eliminarPedido() {

        if (txtPedId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un pedido.");
            return;
        }

        try {

            pedidoDAO.delete(
                    Integer.parseInt(txtPedId.getText())
            );

            JOptionPane.showMessageDialog(this,
                    "Pedido eliminado.");

            limpiarPedido();
            cargarPedidos();
            cargarCombosEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void limpiarPedido() {

        txtPedId.setText("");
        txtDireccion.setText("");

        comboTipo.setSelectedIndex(0);
        comboEstado.setSelectedIndex(0);

        tablaPedidos.clearSelection();
    }

    private void cargarPedidos() {

        modeloPedidos.setRowCount(0);

        try {

            List<Pedido> lista = pedidoDAO.readAll();

            for (Pedido p : lista) {

                modeloPedidos.addRow(new Object[]{
                        p.getId(),
                        p.getDireccion(),
                        p.getTipo(),
                        p.getEstado()
                });
            }

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }


    private JPanel panelEntregas() {

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JPanel formulario = new JPanel(new GridLayout(3, 4, 5, 5));

        txtEntId = new JTextField();
        txtEntId.setEditable(false);

        comboPedido = new JComboBox<>();
        comboRepartidor = new JComboBox<>();

        txtFecha = new JTextField(
                LocalDate.now().toString()
        );

        txtHora = new JTextField(
                LocalTime.now()
                        .withNano(0)
                        .toString()
        );

        JButton btnGuardar = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        formulario.add(new JLabel("ID:"));
        formulario.add(txtEntId);

        formulario.add(new JLabel("Pedido:"));
        formulario.add(comboPedido);

        formulario.add(new JLabel("Repartidor:"));
        formulario.add(comboRepartidor);

        formulario.add(new JLabel("Fecha (AAAA-MM-DD):"));
        formulario.add(txtFecha);

        formulario.add(new JLabel("Hora (HH:MM:SS):"));
        formulario.add(txtHora);

        formulario.add(btnGuardar);
        formulario.add(btnActualizar);

        panel.add(formulario, BorderLayout.NORTH);

        JPanel botones = new JPanel();

        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        panel.add(botones, BorderLayout.SOUTH);

        modeloEntregas = new DefaultTableModel(
                new String[]{
                        "ID", "Pedido", "Repartidor", "Fecha", "Hora"
                }, 0
        );

        tablaEntregas = new JTable(modeloEntregas);

        panel.add(new JScrollPane(tablaEntregas),
                BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardarEntrega());
        btnActualizar.addActionListener(e -> actualizarEntrega());
        btnEliminar.addActionListener(e -> eliminarEntrega());
        btnLimpiar.addActionListener(e -> limpiarEntrega());

        tablaEntregas.getSelectionModel().addListSelectionListener(e -> {

            int fila = tablaEntregas.getSelectedRow();

            if (fila >= 0) {

                txtEntId.setText(
                        modeloEntregas.getValueAt(fila, 0).toString()
                );

                int idPedido = Integer.parseInt(
                        modeloEntregas.getValueAt(fila, 1).toString()
                );

                int idRepartidor = Integer.parseInt(
                        modeloEntregas.getValueAt(fila, 2).toString()
                );

                seleccionarPedido(idPedido);
                seleccionarRepartidor(idRepartidor);

                txtFecha.setText(
                        modeloEntregas.getValueAt(fila, 3).toString()
                );

                txtHora.setText(
                        modeloEntregas.getValueAt(fila, 4).toString()
                );
            }
        });

        return panel;
    }

    private void guardarEntrega() {

        try {

            Pedido pedido =
                    (Pedido) comboPedido.getSelectedItem();

            Repartidor repartidor =
                    (Repartidor) comboRepartidor.getSelectedItem();

            if (pedido == null || repartidor == null) {

                JOptionPane.showMessageDialog(this,
                        "Debe seleccionar pedido y repartidor.");

                return;
            }

            LocalDate fecha =
                    LocalDate.parse(txtFecha.getText().trim());

            LocalTime hora =
                    LocalTime.parse(txtHora.getText().trim());

            Entrega e = new Entrega(
                    pedido.getId(),
                    repartidor.getId(),
                    fecha,
                    hora
            );

            entregaDAO.create(e);

            JOptionPane.showMessageDialog(this,
                    "Entrega registrada correctamente.");

            limpiarEntrega();
            cargarEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void actualizarEntrega() {

        if (txtEntId.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Seleccione una entrega.");

            return;
        }

        try {

            Pedido pedido =
                    (Pedido) comboPedido.getSelectedItem();

            Repartidor repartidor =
                    (Repartidor) comboRepartidor.getSelectedItem();

            LocalDate fecha =
                    LocalDate.parse(txtFecha.getText().trim());

            LocalTime hora =
                    LocalTime.parse(txtHora.getText().trim());

            Entrega e = new Entrega(
                    Integer.parseInt(txtEntId.getText()),
                    pedido.getId(),
                    repartidor.getId(),
                    fecha,
                    hora
            );

            entregaDAO.update(e);

            JOptionPane.showMessageDialog(this,
                    "Entrega actualizada.");

            limpiarEntrega();
            cargarEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void eliminarEntrega() {

        if (txtEntId.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Seleccione una entrega.");

            return;
        }

        try {

            entregaDAO.delete(
                    Integer.parseInt(txtEntId.getText())
            );

            JOptionPane.showMessageDialog(this,
                    "Entrega eliminada.");

            limpiarEntrega();
            cargarEntregas();

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void limpiarEntrega() {

        txtEntId.setText("");

        if (comboPedido.getItemCount() > 0) {
            comboPedido.setSelectedIndex(0);
        }

        if (comboRepartidor.getItemCount() > 0) {
            comboRepartidor.setSelectedIndex(0);
        }

        txtFecha.setText(LocalDate.now().toString());

        txtHora.setText(
                LocalTime.now()
                        .withNano(0)
                        .toString()
        );

        tablaEntregas.clearSelection();
    }

    private void cargarEntregas() {

        modeloEntregas.setRowCount(0);

        try {

            List<Entrega> lista = entregaDAO.readAll();

            for (Entrega e : lista) {

                modeloEntregas.addRow(new Object[]{
                        e.getId(),
                        e.getIdPedido(),
                        e.getIdRepartidor(),
                        e.getFecha(),
                        e.getHora()
                });
            }

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void cargarCombosEntregas() {

        try {

            comboPedido.removeAllItems();
            comboRepartidor.removeAllItems();

            for (Pedido p : pedidoDAO.readAll()) {
                comboPedido.addItem(p);
            }

            for (Repartidor r : repartidorDAO.readAll()) {
                comboRepartidor.addItem(r);
            }

        } catch (Exception ex) {

            mostrarError(ex);
        }
    }

    private void seleccionarPedido(int id) {

        for (int i = 0; i < comboPedido.getItemCount(); i++) {

            Pedido p = comboPedido.getItemAt(i);

            if (p.getId() == id) {

                comboPedido.setSelectedIndex(i);
                break;
            }
        }
    }

    private void seleccionarRepartidor(int id) {

        for (int i = 0; i < comboRepartidor.getItemCount(); i++) {

            Repartidor r = comboRepartidor.getItemAt(i);

            if (r.getId() == id) {

                comboRepartidor.setSelectedIndex(i);
                break;
            }
        }
    }

    private void mostrarError(Exception ex) {

        JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );

        ex.printStackTrace();
    }
}